package j100projects.project04.yapayversion;

public class Runner {
    public static void main(String[] args) {
        GameManager gameManager = new GameManager();
        gameManager.startGame();
    }
}
